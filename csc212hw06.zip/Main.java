/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csc212hw06;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
          Scanner kb= new Scanner(System.in);
        System.out.println("Welcome to Oswego Airlines");

        System.out.println("Enter a flight number:");
        String flightNumber = kb.nextLine();

        System.out.println("Enter the number of rows:");
        int row = kb.nextInt();

        System.out.println("Enter the number of seats per row:");
        int column = kb.nextInt();
        
        Plane name = new Plane (flightNumber, row, column);
        System.out.println("Enter add, remove, seats, list, or quit:");
        String userInput = kb.nextLine();
        userInput = kb.nextLine();

        while (!userInput.equals("quit")) {
            if (userInput.equals("add")) {
                System.out.println("Enter passenger name, row, and seat:");
                
                userInput = kb.nextLine();
                Scanner sc = new Scanner(userInput);

                name.addPassenger(sc.next(), sc.nextInt(), sc.nextInt());

            } else if (userInput.equals("remove")) {
                System.out.println("Enter row and seat:");
                userInput = kb.nextLine();
                Scanner sc = new Scanner(userInput);
                name.removePassenger(sc.nextInt(), sc.nextInt());
            } else if (userInput.equals("seats")) {
                name.showSeats();
            } else if (userInput.equals("list")) {
                name.passengerList();
            } else 
            {
                System.out.println("Unknown command -- please try again.");
            }
            
            System.out.println("Enter add, remove, seats, list, or quit:");
             userInput = kb.nextLine();
        }
        System.out.println("Closing Oswego Airlines");
        
    }
    
}

    
    
