/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csc212hw06;

/**
 *
 * @author jijomah
 */
public class Plane {
     int row;
    int column;
    private Passenger[][] people;
    String flightNumber;

    public Plane(String fn, int rn, int sr) {
        people = new Passenger[rn][sr];
        flightNumber = fn;
        row = rn;
        column = sr;
    }

    public boolean addPassenger(String pn, int r, int rs) {
        if (r < row && r >= 0 && rs < column && rs >= 0 && people[r][rs] == null) {
            people[r][rs] = new Passenger(pn);
            System.out.println("Passenger " + people[r][rs].getName() + " was added.");
            return true;
        } else {
            System.out.println("Invalid seat -- please try again.");
            return false;
        }
    }

    public boolean removePassenger(int r, int rs) {
        if (r < row && r >= 0 && rs < column && rs >= 0 && people[r][rs] != null) {
            people[r][rs] = null;
            System.out.println("Passenger was removed.");
            return true;
        } else {
            System.out.println("Invalid seat -- please try again.");
            return false;
        }
    }

    public void showSeats() {
        System.out.print("  ");
        for (int j = 0; j < people[0].length; j++) {
            System.out.printf("|%10d|", j);
        }
        System.out.println();
        // Display the contents of the machine
        for (int i = 0; i < people.length; i++) {
            // Display the row label
            System.out.printf("%2d", i);
            for (int j = 0; j < people[i].length; j++) {
                if (people[i][j] == null) {
                    // slot is empty 
                    System.out.printf("|%10s|", "");
                } else {
                    System.out.printf("|%10s|", people[i][j].getName());
                }
            }
            System.out.println();
        }

    }

    public void passengerList() {
        for (int i = 0; i < people.length; i++) {
            for (int j = 0; j < people[0].length; j++) {
                if (people[i][j] != null) {
                    System.out.println(people[i][j].toString());
                }
            }

        }

    }

}

