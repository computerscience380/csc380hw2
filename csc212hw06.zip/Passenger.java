/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csc212hw06;
import java.text.DecimalFormat;
import java.util.Random;



/**
 *
 * @author user
 */
public class Passenger {
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    private String name;
    private double fare;

    Random r = new Random();

    public Passenger(String n) {
        fare = 100 + (500 - 100) * r.nextDouble();

        name = n;

    }

    public String getName() {
        return name;
    }

    public String toString() {
        DecimalFormat df = new DecimalFormat("0.00");
        return "Name:" + name + "fare:" + df.format(fare);
    }
        
                
    }
    





/*
Should have the following private variables
○ String name
○ double fare
● A constructor method that accepts a String parameter to initialize the name. It also
generates a random double between 100 and 500 and initializes the fare.
● A getName()method that returns the name of the passenger
● A toString()method that returns a String containing all the variables with a label
(as shown in the example)
*/